import org.junit.jupiter.api.Test;

import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;
public class WatchTest {
    Watch watch = new Watch();
    @Test
    public void test1(){
        assertEquals(watch.displayTIME(),"time is " + LocalTime.now().toSecondOfDay());
    }
    @Test
    public void test2(){
        assertEquals(watch.adjustTIME("10:20"), "new time is 10:20");
    }
    @Test
    public void test3() {
        assertEquals(watch.displayTIME(),"time is " + LocalTime.now().toSecondOfDay());
        assertEquals(watch.adjustTIME("22:20"), "new time is 22:20");
    }
}
