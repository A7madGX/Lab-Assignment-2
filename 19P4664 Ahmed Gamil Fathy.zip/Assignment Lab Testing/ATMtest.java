import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ATMtest {
    ATM atm = new ATM(5000);
    @Test
    public void test1(){
        assertEquals(atm.deposit(2000),"Transaction is Successful");
    }
    @Test
    public void test2(){
        assertEquals(atm.withdraw(1500),"Transaction is Successful");
    }
    @Test
    public void test3(){
        assertEquals(atm.withdraw(3000),"Transaction is Successful");
    }
    @Test
    public void test4(){
        assertEquals(atm.withdraw(8000),"Transaction is Unsuccessful");
    }
    @Test
    public void test5(){
        assertEquals(atm.getReceipt(),"Balance: " + atm.balance);
    }
    @Test
    public void test6(){
        assertEquals(atm.deposit(2000),"Transaction is Successful");
        assertEquals(atm.withdraw(1500),"Transaction is Successful");
    }
    @Test
    public void test7(){
        assertEquals(atm.deposit(2000),"Transaction is Successful");
        assertEquals(atm.withdraw(1500),"Transaction is Successful");
        assertEquals(atm.getReceipt(),"Balance: " + atm.balance);
    }
}
