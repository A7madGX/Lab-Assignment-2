
public class ATM {

    int balance;

    ATM(int balance){
        this.balance = balance;
    }

    public String deposit(int cash){
        this.balance += cash;
        return ("Transaction is Successful");
    }

    public String withdraw(int cash){
        if (cash <= this.balance) {
           this.balance -= cash; 
           return ("Transaction is Successful");
        }else{
            return ("Transaction is Unsuccessful");
        }
    }

    public String getReceipt(){
        return ("Balance: " + this.balance);
    }


}